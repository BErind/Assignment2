package assignment2;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Read2014302580059 {
	public static void main(String args[]) throws IOException{
		Document doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Chen%20Beibei").get();
		
		//����ҳ�ϵ�������ѡ����ѡ�񣬲����������result��
		File file = new File("result.txt");
		Elements name1 = doc.select("h3");
		Elements p = doc.select("p");
		String name2 = name1.text();
		String result = p.text();
		
		//��result��������ƥ��
		Pattern intro1 = Pattern.compile("��ʿ , ������"); 
		Matcher intro2 = intro1.matcher(result);
		
		Pattern dir1 = Pattern.compile("�о�.*���׷���"); 
		Matcher dir2 = dir1.matcher(result);
		
		Pattern email1 = Pattern.compile("[a-z0-9]*@[a-z0-9.]*"); 
		Matcher email2 = email1.matcher(result);
		
		Pattern num1 = Pattern.compile("[0-9]{3}-[0-9]{8}"); 
		Matcher num2 = num1.matcher(result);

		//�����ļ�
        FileWriter fileWriter = new FileWriter(file); 
        
        //�������
        fileWriter.write(name2); 
        fileWriter.write("\r\n"); 

        while (intro2.find()){
            fileWriter.write(intro2.group()+"\r\n");
        }
        while (dir2.find()){
            fileWriter.write(dir2.group()+"\r\n");
        }
        while (email2.find()){
            fileWriter.write(email2.group()+"\r\n");
        }
        while (num2.find()){
            fileWriter.write(num2.group()+"\r\n");
        }
        //��ֹ������
        fileWriter.close(); 

	}

}
